export const WORLD_BOUNDS = [
    [-85, -180],
    [85, 180],
];
