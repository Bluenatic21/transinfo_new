// @ts-nocheck
// Обёртка для совместимости: если где-то импортируется .tsx — прокидываем на .jsx
export { default } from "./OrdersTabs.jsx";
export * from "./OrdersTabs.jsx";
